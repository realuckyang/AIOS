# AIOS

由外部 Boot 管理无持久状态 Kernel 与有状态 App 的 Agent 系统。设计见 [`.dev/docs/`](.dev/docs/README.md)。

- **boot.js**：系统启动器，按顺序启动 Kernel 与 App，监控并重启子进程。
- **kernel/**：单次 run 执行引擎，只在内存维护本轮上下文、模型工具循环、bash、工具与 run API。
- **bin/**：出厂可执行程序：guard 与 `read`/`write`/`edit` 文件工具。
- **app/**：有状态应用层。`server/` 拥有 chats API、调度、SSE 与持久化；`ui/` 是 React 前端。
- **var/**：App 的持久事实，保存 SQLite 数据库 `aios.db`。
- **run/**：系统临时运行状态，目前只保存 `boot.pid`。
- **etc/**：结构化运行参数、模型指令与工具注册。
- **.dev/**：设计文档与历史版本；`lib/` 中保留 v1–v3。

## 快速开始

需要 Node.js 22+ 和一个兼容 OpenAI Responses API 的模型服务。

```bash
cp etc/config.example.json etc/config.json
# 填写 responsesUrl、apiKey、model

cd app/ui
npm install
npm run build
cd ../..

npm start
```

浏览器打开 <http://127.0.0.1:9523>，或使用 tty：

```bash
npm run console
```

| 命令 | 作用 |
| --- | --- |
| `npm start` | 启动 Boot，由它依次拉起 Kernel `:9522` 和 App `:9523` |
| `npm stop` | 通知 Boot 统一关闭 App 和 Kernel |
| `npm run kernel` | 只启动 Kernel，用于独立调试 |
| `npm run app` | 只启动 App；端口来自环境变量或默认值 |
| `npm run console -- [chat-id]` | 打开终端对话客户端 |

## 安全说明

这个 agent 能执行命令并修改文件，只在信任的机器上运行，不要暴露到公网。`var/`、`run/` 与 `etc/config.json` 已被 Git 忽略。
